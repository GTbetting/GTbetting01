export default function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>GTBetting no ar 🔥</h1>
      <p>Versão final pronta para deploy real na Cloudflare Pages</p>
    </div>
  );
}